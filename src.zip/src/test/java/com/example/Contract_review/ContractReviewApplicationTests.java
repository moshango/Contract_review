package com.example.Contract_review;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContractReviewApplicationTests {

	@Test
	void contextLoads() {
	}

}
